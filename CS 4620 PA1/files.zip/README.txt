CS 4620: Introduction to Computer Graphics
Fall 2012
Arjun Biddanda (aab227)
Muhammad Khan (mhk98)

Problems: The cylinder in problem 2 is not being fully rendered. This is definitely not a problem with the rendering but rather our code but we can't figure out where it's going wrong.

Miscellaneous: Both of us just added this course on the add course deadline, so it's been tough trying to catch up with the past material while also staying on top of the current material like the first homework and this first problem set. Please take this into account while grading, because the quality of work in this particular problem set is not an entirely accurate reflection of our programming skills or our understanding of the material.
